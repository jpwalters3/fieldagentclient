import React from 'react'

const header = () => {
  return (
    <div name = "hd">
    <h1> Agent Controll Center </h1>
    </div>
  )
}

export default header
